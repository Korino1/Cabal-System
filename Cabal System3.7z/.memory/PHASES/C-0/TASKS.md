---
id: tasks_phase
phase: C-0
updated: 2026-02-08
---
# Tasks (phase)

- [ ] T C-0.0 — Сквозные правила (опросник + фиксация запретов/разрешений в CONCEPT_MASTER) [Owner: conceptualizer]
- [ ] T C-0.MATH — Математическое обоснование (CONCEPT_MATH_PROOF: леммы/инварианты/коридоры параметров) [Owner: mathematician]
- [ ] T C-0.1 — Сбор и синтез концепта [Owner: conceptualizer]
- [ ] T C-0.2 — Проверка корректности и правки [Owner: conceptualizer]

## Link to Global TASKS
- Ref: US/FEAT in .memory/TASKS.md
