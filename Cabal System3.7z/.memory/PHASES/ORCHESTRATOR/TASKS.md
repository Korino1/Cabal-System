---
id: tasks_phase
phase: ORCHESTRATOR
updated: 2026-01-29
---
# Tasks (phase)

## Status
- Deprecated: tasks are split by stage under .memory/PHASES/ORCHESTRATOR/STAGES

## Active Stage Tasks
- .memory/PHASES/ORCHESTRATOR/STAGES/S1/TASKS.md

## Stage Index
- .memory/PHASES/ORCHESTRATOR/STAGES/INDEX.md

