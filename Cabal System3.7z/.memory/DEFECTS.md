---
id: defects
updated: 2025-12-26
owner: techlead
---
# Defects (handoff)
| ID | Date | Source | Summary | Status | Owner | Link |
| --- | --- | ------ | ------- | ------ | ----- | ---- |

## Template
```
## DEF-YYYYMMDD-###
- Status: New | Triaged | InFix | Fixed | Verified
- Source: debuger
- Related Tasks: T BASE...
- Summary:
- Symptoms:
- Repro:
- Root Cause:
- Scope/Impact:
- Suspected Files:
- Fix Plan:
- Tests:
- Risks:
- Notes:
```


